Copyright Kim Venetvirta (C) 2012 tardolus@ovi.com
